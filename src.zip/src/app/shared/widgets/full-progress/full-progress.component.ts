import { Component, OnInit } from '@angular/core';
import { NgCircleProgressModule } from 'ng-circle-progress';
import { CircleProgressOptions } from 'ng-circle-progress';

@Component({
  selector: 'app-full-progress',
  templateUrl: './full-progress.component.html',
  styleUrls: ['./full-progress.component.scss']
})
export class FullProgressComponent {

 
  constructor() { }

  // ngOnInit() {
  //    this.progressOptions = {
  //     radius: 100,
  //     outerStrokeWidth: 16,
  //     innerStrokeWidth: 8,
  //     outerStrokeColor: '#78C000',
  //     innerStrokeColor: '#C7E596',
  //     animationDuration: 300,
  //     class: '',
  //     backgroundGradient: false,
  //     backgroundColor: '',
  //     backgroundGradientStopColor: '',
  //     backgroundOpacity: 0,
  //     backgroundStroke: '',
  //     backgroundStrokeWidth: 0,
  //     backgroundPadding: 0,
  //     percent: 0,
  //     space: 0,
  //     toFixed: 0,
  //     maxPercent: 0,
  //     renderOnClick: false,
  //     units: '',
  //     unitsFontSize: '',
  //     unitsFontWeight: '',
  //     unitsColor: '',
  //     outerStrokeGradient: false,
  //     outerStrokeGradientStopColor: '',
  //     outerStrokeLinecap: '',
  //     titleFormat: undefined,
  //     title: '',
  //     titleColor: '',
  //     titleFontSize: '',
  //     titleFontWeight: '',
  //     subtitleFormat: undefined,
  //     subtitle: '',
  //     subtitleColor: '',
  //     subtitleFontSize: '',
  //     subtitleFontWeight: '',
  //     imageSrc: undefined,
  //     imageHeight: undefined,
  //     imageWidth: undefined,
  //     animation: false,
  //     animateTitle: false,
  //     animateSubtitle: false,
  //     showTitle: false,
  //     showSubtitle: false,
  //     showUnits: false,
  //     showImage: false,
  //     showBackground: false,
  //     showInnerStroke: false,
  //     clockwise: false,
  //     responsive: false,
  //     startFromZero: false,
  //     showZeroOuterStroke: false,
  //     lazy: false
  //   };
    
  // }

}
